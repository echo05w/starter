# My Full-Stack Starter

This template includes:
- **Backend**: Express API with CORS, dotenv, logging, and sample `/data` + `/countries` routes.
- **Frontend**: Vite + React app that fetches the API and shows countries with search & region filter.
- **Root script**: Run both servers with one command via `concurrently`.

## Quick Start

```bash
# In the project root
npm install          # installs root dev deps (concurrently)
npm install --prefix backend
npm install --prefix frontend

# Run both servers
npm start
```

- Backend → http://localhost:3000
- Frontend → http://localhost:3001

Set `frontend/.env` to point to production API later:
```
VITE_API_URL=https://your-backend.example.com
```

Back-end env is in `backend/.env` (copy from `.env.example`).
