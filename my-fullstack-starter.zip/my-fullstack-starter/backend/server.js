// Backend: Express API
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import morgan from "morgan";
import axios from "axios";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

app.get("/health", (req, res) => {
  res.json({ ok: true, uptime: process.uptime(), env: process.env.NODE_ENV || "dev" });
});

// Simple demo route
app.get("/data", (req, res) => {
  res.json({ message: "API ready!" });
});

// Countries route (optional fields & region)
app.get("/countries", async (req, res) => {
  try {
    const { fields, region } = req.query;
    const url = fields
      ? `https://restcountries.com/v3.1/all?fields=${encodeURIComponent(fields)}`
      : `https://restcountries.com/v3.1/all`;

    const { data: raw } = await axios.get(url, { timeout: 15000 });

    const base = fields
      ? raw
      : raw.map((c) => ({
          name: c?.name?.common,
          cca2: c?.cca2,
          region: c?.region,
          flags: c?.flags,
          flagPng: c?.flags?.png,
        }));

    const filtered = region ? base.filter((c) => c?.region === region) : base;
    res.json(filtered);
  } catch (e) {
    console.error("Countries error:", e.message);
    res.status(500).json({ error: true, message: e.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Backend on http://localhost:${PORT}`);
});
