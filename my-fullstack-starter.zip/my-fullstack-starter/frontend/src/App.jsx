import { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:3000'

export default function App() {
  const [msg, setMsg] = useState('Loading…')
  const [countries, setCountries] = useState([])
  const [query, setQuery] = useState('')
  const [region, setRegion] = useState('')

  useEffect(() => {
    fetch(`${API}/data`)
      .then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`)))
      .then(d => setMsg(d.message))
      .catch(() => setMsg('Failed to reach backend'))
  }, [])

  useEffect(() => {
    fetch(`${API}/countries?fields=name,cca2,region,flags`)
      .then(r => r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`)))
      .then(d => setCountries(d))
      .catch(() => setCountries([]))
  }, [])

  const shown = countries
    .filter(c => (region ? c.region === region : true))
    .filter(c => c.name.toLowerCase().includes(query.toLowerCase()))

  return (
    <main style={{ padding: 24, fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif' }}>
      <h1>🌍 My Full-Stack App</h1>
      <p>{msg}</p>

      <div style={{ display: 'flex', gap: 8, margin: '16px 0' }}>
        <input
          placeholder="Search country…"
          value={query}
          onChange={e => setQuery(e.target.value)}
          style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc', minWidth: 220 }}
        />
        <select
          value={region}
          onChange={e => setRegion(e.target.value)}
          style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }}
        >
          <option value="">All regions</option>
          <option>Africa</option>
          <option>Americas</option>
          <option>Asia</option>
          <option>Europe</option>
          <option>Oceania</option>
          <option>Antarctic</option>
        </select>
        <button onClick={() => { setQuery(''); setRegion(''); }}>Clear</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 12 }}>
        {shown.map(c => (
          <article key={c.cca2} style={{ background:'#fff', padding:12, borderRadius:8, boxShadow:'0 2px 6px rgba(0,0,0,.1)' }}>
            {c.flags?.png && <img src={c.flags.png} alt={c.name} style={{ width: '100%', borderRadius: 8 }} />}
            <h3 style={{ margin: '8px 0' }}>{c.name}</h3>
            <small>{c.region}</small>
          </article>
        ))}
      </div>
    </main>
  )
}
